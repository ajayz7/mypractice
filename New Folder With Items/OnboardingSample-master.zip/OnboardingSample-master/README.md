# OnboardingSample
Beginners - A demo of an onboarding screen in iOS using Swift<br/> 

<br/> 
<br/> 

![Alt Text](https://github.com/anitaa1990/OnboardingSample/blob/master/media/promo.gif)
